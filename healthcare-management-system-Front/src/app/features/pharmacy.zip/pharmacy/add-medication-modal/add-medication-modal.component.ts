import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }  from '@angular/forms';
import { MedicationService, Medication } from '../../../core/services/medication.service';


@Component({
  selector: 'app-add-medication-modal',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-medication-modal.component.html',
})
export class AddMedicationModalComponent implements OnInit, OnChanges {
  @Input() visible = false;
  @Output() close = new EventEmitter<void>();
  @Output() save  = new EventEmitter<{
    medicationId: number;
    quantity:      number;
    status:        string;
  }[]>();

  /** Número de filas y datos */
  count = 1;
  rows: { medicationId: number|null; quantity: number|null; status: string }[] = [];

  /** Datos de la API */
  medications: Medication[] = [];
  statuses = [
    { value: 'PENDING',     label: 'Pendiente' },
    { value: 'ACCEPTED',    label: 'Aceptado' },
    { value: 'REJECTED',    label: 'Rechazado' },
    { value: 'BACKORDERED', label: 'Backorder' },
  ];

  constructor(private medSvc: MedicationService) {}

  ngOnInit() {
    // Cargo el catálogo de medicamentos una vez
    this.medSvc.getAll().subscribe(list => (this.medications = list));
  }

  ngOnChanges(changes: SimpleChanges) {
    // Cada vez que abra el modal (visible pase a true), reseteo todo
    if (changes['visible'] && changes['visible'].currentValue) {
      this.count = 1;
      this.generateRows();
    }
  }

  generateRows() {
    this.rows = Array.from({ length: this.count }, () => ({
      medicationId: null,
      quantity:      null,
      status:        'PENDING'
    }));
  }

  onSave() {
    // Emite solo datos válidos
    this.save.emit(
      this.rows.map(r => ({
        medicationId: r.medicationId!,
        quantity:      r.quantity!,
        status:        r.status
      }))
    );
    this.close.emit();
  }
}
